package com.example.flutter_sqlite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
