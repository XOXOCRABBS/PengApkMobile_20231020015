# Tugas 8 dan 9 Flutter SQLite
## Kelompok  
- Ilham Aryasuta Jati Nugroho (20231020070)  
- Geraldy Cornelius Kartika (20231020015)  